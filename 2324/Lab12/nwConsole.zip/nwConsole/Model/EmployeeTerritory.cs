﻿using System;
using System.Collections.Generic;

namespace nwConsole.Model;

public partial class EmployeeTerritory
{
    public int EmployeeId { get; set; }

    public string TerritoryId { get; set; } = null!;
}
