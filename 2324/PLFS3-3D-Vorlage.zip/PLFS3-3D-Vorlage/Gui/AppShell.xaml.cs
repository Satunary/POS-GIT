﻿namespace Plfs3 {
    public partial class AppShell : Shell {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
