namespace EfCoreDemo2;

public partial class NewExamPage : ContentPage
{
	public NewExamPage()
	{
		InitializeComponent();
	}
}