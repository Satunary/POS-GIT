﻿
using EfCoreDemoV2.ViewModels;

namespace EfCoreDemoV2;

public partial class MainPage : ContentPage {
    
    public MainPage()
    {
        InitializeComponent();

        
    }

    
}
