package com.example.temp;

import javafx.scene.layout.Pane;

public class View extends Pane {


}
