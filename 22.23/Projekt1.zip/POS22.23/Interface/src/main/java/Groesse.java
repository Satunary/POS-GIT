public interface Groesse {
}
