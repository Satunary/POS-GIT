
public class USBStick
{
    private String kennzeichen;
    private int groesseInMB;
    private int verkaufsPreis;
    
    public USBStick()
    {
        setKennzeichen("USB");
        setGroesseInMB(1000);
        setVerkaufsPreis(50);
    }
    public USBStick(String kennzeichen, int groesseInMB, int verkaufsPreis)
    {
       setKennzeichen(kennzeichen);
        setGroesseInMB(groesseInMB);
        setVerkaufsPreis(verkaufsPreis); 
    }
    
    public void setKennzeichen(String kennzeichen)
    {
        this.kennzeichen=kennzeichen;
    }
    public void setGroesseInMB(int groesseInMB)
    {
        if(groesseInMB >=512)
        {
            this.groesseInMB=groesseInMB;
        }
        else
        {
            this.groesseInMB=1000;
        }
    }
    public void setVerkaufsPreis(int verkaufsPreis)
    {
        if(verkaufsPreis>4 && verkaufsPreis<101)
        {
            this.verkaufsPreis=verkaufsPreis;
        }
        else
        {
            System.out.println("ERROR");
            this.verkaufsPreis=50;
        }
    }
    public String getKennzeichen()
    {
        return kennzeichen;
    }
    public int getGroesseInMB()
    {
        return groesseInMB;
    }
    public int getVerkaufsPreis()
    {
        return verkaufsPreis;
    }
    public void print()
    {
        System.out.println("Kennzeichen: "+kennzeichen);
        System.out.println("MB: "+groesseInMB);
        System.out.println("Verkaufspreis: "+verkaufsPreis+"€");
    }
}
