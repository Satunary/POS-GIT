
public class Person
{
    private int alter;
    private int bargeld;
    private boolean schein;
    
    public Person(int alter,int bargeld, boolean schein)
    {
        setAlter(alter);
        setBargeld(bargeld);
        setSchein(schein);
    }
    public Person()
    {
        setAlter(20);
        setBargeld(20000);
        setSchein(true);
    }
    
    public void setAlter (int alter)
    {
        this.alter=alter;
    }
    public void setBargeld(int bargeld)
    {
        this.bargeld=bargeld;
    }
    public void setSchein(boolean schein)
    {
        if(schein)
        {
            if(alter>17)
            {
                this.schein=schein;
                return;
            }
            else
            {
                System.out.println("Zu Jung)");
            }
        }
        this.schein=false;
    }
    public int getBargeld()
    {
        return bargeld;
    }
    public int getAlter()
    {
        return alter;
    }
    public boolean getSchein()
    {
        return schein;
    }
    
    public void zahlen (int betrag)
    {
        if(bargeld >= betrag)
        {
            bargeld=bargeld-betrag;
            System.out.println("Bezahlt");
        }
        else
        {
            System.out.println("Zu wenig Geld");
        }
    }
    public void print()
    {
        System.out.println("Alter: "+alter);
        System.out.println("Bargeld: "+bargeld+"€");
        System.out.println("Hat Führerschein: "+schein);
    }
}
