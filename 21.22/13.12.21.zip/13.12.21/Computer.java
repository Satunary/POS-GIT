
public class Computer
{
    private String name;
    private int verkaufsPreis;
    private USBStick usb0;
    private USBStick usb1;
    
    public Computer()
    {
        setName("Hi");
        setVerkaufsPreis(250);
        usb0=new USBStick("USB", 1000, 50);
        usb1=new USBStick("USB2", 1500, 60);
    }
    public Computer(String name, String kennzeichenUsb0, String kennzeichenUsb1, int verkaufsPreisComputer, int verkaufsPreisUsb0, int verkaufsPreisUsb1, int groesseInMBUsb0, int groesseInMBUsb1)
    {
        setName(name);
        setVerkaufsPreis(verkaufsPreisComputer);
        usb0=new USBStick(kennzeichenUsb0,groesseInMBUsb0,verkaufsPreisUsb0);
        usb1=new USBStick(kennzeichenUsb1,groesseInMBUsb1,verkaufsPreisUsb1);
    }
    
    public void setName(String name)
    {
        this.name=name;
    }
    public void setVerkaufsPreis(int verkaufsPreis)
    {
        if(verkaufsPreis>200)
        {
            this.verkaufsPreis=verkaufsPreis;
        }
        else
        {
            this.verkaufsPreis=250;
        }
    }
    public int getVerkaufsPreis()
    {
        return verkaufsPreis;
    }
    public String getName()
    {
        return name;
    }
    
    public void summeVerkaufsPreis()
    {
        int ergebnis=verkaufsPreis;
        if(!(usb0==null))
        {
            ergebnis=ergebnis+usb0.getVerkaufsPreis();
        }
        if(!(usb1==null))
        {
            ergebnis=ergebnis+usb1.getVerkaufsPreis();
        }
        System.out.println("Insgesamter Verkaufspreis: "+ergebnis+"€");
    }
    public void ansteckenUsb0(String kennzeichen, int groesseInMB, int verkaufsPreis)
    {
        if(usb0==null)
        {
            usb0=new USBStick(kennzeichen,groesseInMB,verkaufsPreis);
        }
        else
        {
            System.out.println("ERROR");
        }
    }
    public void absteckenUsb0()
    {
        usb0=null;
    }
    public void ansteckenUsb1(String kennzeichen, int groesseInMB, int verkaufsPreis)
    {
        if(usb1==null)
        {
            usb1=new USBStick(kennzeichen,groesseInMB,verkaufsPreis);
        }
        else
        {
            System.out.println("ERROR");
        }
    }
    public void absteckenUsb1()
    {
        usb1=null;
    }
    public void print()
    {
        System.out.println("Name: "+name);
        System.out.println("Verkaufspreis: "+verkaufsPreis+"€");
        if(!(usb0==null))
        {
            System.out.println("######USB0######");
            usb0.print();
        }
        if(!(usb1==null))
        {
            System.out.println("#####USB1#####");
            usb1.print();
        }
    }
}
