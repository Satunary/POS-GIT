
public class Sportauto
{
    private int ps;
    private String marke;
    private Person fahrer;
    private Person beiFahrer;
    
    public Sportauto()
    {
        ps=500;
        marke="VW";
        fahrer = new Person(20,20000,true);
        beiFahrer=new Person(14,3000,false);
    }
    public Sportauto(int ps, String marke, int alterFahrer, int alterBeiFahrer,int bargeldFahrer, int bargeldBeiFahrer,boolean scheinFahrer, boolean scheinBeiFahrer)
    {
        setPS(ps);
        setMarke(marke);
        fahrer = new Person(alterFahrer,bargeldFahrer,scheinFahrer);
        beiFahrer=new Person(alterBeiFahrer,bargeldBeiFahrer,scheinBeiFahrer);
    }
    
    public void setPS(int ps)
    {
        this.ps=ps;
    }
    public void setMarke(String marke)
    {
        this.marke=marke;
    }
    public void setFahrer(int alter, int bargeld, boolean schein)
    {
        fahrer=new Person(alter,bargeld,schein);
        if(fahrer == null)
        {
            fahrer = new Person(20,20000,true);
            System.out.println("ERROR");
        }
    }
    public void setBeiFahrer(int alter, int bargeld, boolean schein)
    {
        beiFahrer=new Person(alter,bargeld,schein);
        if(beiFahrer == null)
        {
            beiFahrer = new Person(20,20000,true);
            System.out.println("ERROR");
        }
    }
    public String getMarke()
    {
        return marke;
    }
    public int getPs()
    {
        return ps;
    }
    
    public void schnellfahren(int betrag)
    {
        int x=0;
        int y=0;
        if(!(fahrer==null))
        {
            x=fahrer.getBargeld();
        }
        if(!(beiFahrer==null))
        {
            y=beiFahrer.getBargeld();
        }   
        if((x+y)<betrag)
        {
            System.out.println("Zahlschein um "+(betrag+50)+"€ ausgestellt");
            return;
        }
        if(x>=(betrag/2)&&y>=(betrag/2))
        {
             fahrer.setBargeld((x-(betrag/2)));
             beiFahrer.setBargeld((y-(betrag/2)));
             return;
        }
        else
        {
            int z=betrag-x;
            if(z>0)
            {
                x=0;
                y=y-z;
            }
            else
            {
                x=x-betrag;
            }
            fahrer.setBargeld(x);
            beiFahrer.setBargeld(y);
        }
        
    }
    public void einsteigenFahrer(int alter, int bargeld, boolean schein)
    {
        if(fahrer==null && alter>17 && schein)
        {
            setFahrer(alter,bargeld,schein);
        }
        else
        {
            System.out.println("ERROR");
        }
    }
    public void aussteigenFahrer()
    {
        fahrer=null;
    }
    public void einsteigenBeiFahrer(int alter, int bargeld, boolean schein)
    {
        if(beiFahrer==null)
        {
            setBeiFahrer(alter,bargeld,schein);
        }
        else
        {
            System.out.println("ERROR");
        }
    }
    public void aussteigenBeiFahrer()
    {
        beiFahrer=null;
    }
    public void print()
    {
        System.out.println("PS: "+ps);
        System.out.println("Marke: "+marke);
        
        if(fahrer==null)
        {
            
        }
        else
        {
            System.out.println("#######Fahrer#########");
            fahrer.print();
        }
        if(beiFahrer==null)
        {
            
        }
        else
        {
            System.out.println("########Beifahrer######");
            beiFahrer.print();
        }
    }
}
